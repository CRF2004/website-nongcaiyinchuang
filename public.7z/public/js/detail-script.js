// 获取URL中的需求ID
const urlParams = new URLSearchParams(window.location.search);
const demandId = urlParams.get('id');

fetch('data/demands.json')
.then(response => response.json())
.then(data => {
    mockDemands = data;
    const demand = mockDemands.find(d => d.id == demandId);
    if (demand) {
        document.getElementById('demandTitle').textContent = demand.title;
        document.getElementById('demandDescription').textContent = demand.description;
        document.getElementById('demandCategory').textContent = `Category: ${demand.category}`;
        document.getElementById('demandBudget').textContent = `Budget: $${demand.budget}`;
        document.getElementById('demandPostedDate').textContent = `Posted on: ${new Date(demand.postedDate).toLocaleDateString()}`;
        document.getElementById('demandDetail').textContent = demand.detail;
    } else {
        // 如果未找到需求，显示错误信息
        document.getElementById('demandTitle').textContent = "Demand not found";
    }
})
.catch(error => console.error('Error:', error));