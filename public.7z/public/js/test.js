// fetch('http://localhost:3000/public/data')
//     .then(response => {response.json();console.log(response)})
//     .then(data => {
//         console.log(data)
//     })
//     .catch(error => console.error('获取用户数据时出错:', error));