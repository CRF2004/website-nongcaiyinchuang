document.addEventListener('DOMContentLoaded', () => {
    const paginatorElement = document.getElementById('paginator');
    // 检查是否成功获取到了元素
    if (!paginatorElement) {
        console.error("Paginator element not found");
        return;
    }
    let target;
    const type = paginatorElement.getAttribute('data-type'); // 获取 data-type 属性
    if (type == "demand"){
        target = '../data/demands.json';}
    else {target = '../data/supply.json';}
    
    fetch(target)
    .then(response => response.json())
    .then(data => {
        mockDemands = data;
        // 初次加载时进行分页
        paginateDemands(mockDemands, type);
    })
    .catch(error => console.error('Error:', error));
});

function fetchDemands(type) {
    // 获取搜索框的输入元素
    const searchInputElement = document.getElementById('searchInput');
    // 如果有搜索框，获取输入值；没有则设为空字符串
    const searchQuery = searchInputElement ? searchInputElement.value.toLowerCase() : ''; 

    // 获取当前激活的分类按钮
    const activeCategoryButton = document.querySelector('.vui_button--active');
    const category = activeCategoryButton && activeCategoryButton.getAttribute('data-category') 
    ? activeCategoryButton.getAttribute('data-category').toLowerCase() 
    : ''; // 获取分类
    let target;
    if (type == "demand"){
        target = '../data/demands.json';}
    else {target = '../data/supply.json';}

    fetch(target)
    .then(response => response.json())
    .then(data => {
        mockDemands = data;
        // 初次加载时进行分页
        const filteredDemands = mockDemands.filter(demand => {
            const matchesSearchQuery = demand.title.toLowerCase().includes(searchQuery) || demand.description.toLowerCase().includes(searchQuery);
            const matchesCategory = category === '' || demand.category.toLowerCase() === category;
            return matchesSearchQuery && matchesCategory;
            }
        );
        const parentElement = $('#demandList');
        let type;
        if (target == '../data/demands.json'){
            type = "demand";}
        else {type = "supply";}
        displayDemands(filteredDemands, parentElement, type);}
        )
    .catch(error => console.error('Error:', error));

// 获取父元素，传递给 displayDemands 函数         服务器部署后使用
//   const parentElement = $('#demandList');
//   displayDemands(filteredDemands, parentElement);
//   console.log("??????")
//   const xhr = new XMLHttpRequest();
//   xhr.open('GET', `/api/demands?search=${searchQuery}&category=${category}`, true); // 假设API路径为 /api/demands
//   xhr.onload = function () {
//       if (xhr.status === 200) {
//           const demands = JSON.parse(xhr.responseText);
//           displayDemands(demands);
//       }
//   };
//   xhr.send();
}
function displayDemands(items, parentElement, type) {
    parentElement.empty();
    items.forEach(item => {
        let itemHtml;

        if (type == "demand") {
            itemHtml = `
                <h3>${item.title}</h3>
                <p>${item.description}</p>
                <p>类别: ${item.category}</p>
                <p>期望金额: $${item.budget}</p>
                <p>发表日期: ${new Date(item.postedDate).toLocaleDateString()}</p>
            `;
        } else if (type == "supply") {
            itemHtml = `
                <h3>${item.title}</h3>
                <p>技能: ${item.skills}</p>
                <p>${item.description}</p>
                <p>期望薪资: $${item.expectedPayment}</p>
            `;
        } 
        const itemElement = $('<div>', {
            class: 'demand-item',
            'data-id': item.id
        }).html(itemHtml);
        parentElement.append(itemElement);
    });
}

let currentPage = 1;
let itemsPerPage = 3; // 每页显示的需求数量
let totalPages = 4;
function paginateDemands(demands, type) {         // 动态生成分页
    const demandList = $('#demandList');
    demandList.empty();
    totalPages = Math.ceil(demands.length / itemsPerPage);
    for (let i = 0; i < totalPages; i++) {
        const pageElement = document.createElement('div');
        pageElement.className = 'page';
        pageElement.id = `page${i + 1}`;
        if (i > 0) pageElement.style.display = 'none';
        const start = i * itemsPerPage;
        const end = start + itemsPerPage;
        const pageDemands = demands.slice(start, end);
        // 动态显示需求列表
        displayDemands(pageDemands, $(pageElement), type);
        demandList.append(pageElement);
    }
    showPage(currentPage);
}

// 显示当前页，隐藏其他页
function showPage(pageNumber) {
    $('.page').hide(); // 隐藏所有页
    $(`#page${pageNumber}`).show(); // 仅显示当前页
}

$(document).ready(function() {
    $('#demandList').on('click', '.demand-item', function(event) {
        const demandId = $(this).data('id');
        window.location.href = `demand-detail.html?id=${demandId}`;
    });
})

// 上一页
function prevPage() {
    if (currentPage > 1) {
        currentPage--;
        showPage(currentPage);
    }
}

// 下一页
function nextPage() {
    if (currentPage < totalPages) {
        currentPage++;
        showPage(currentPage);
    }
}
