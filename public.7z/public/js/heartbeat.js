function startHeartbeat() {
    setInterval(() => {
        fetch('/heartbeat', {
            method: 'GET',
            credentials: 'include' // 确保发送 cookies，保持会话
        })
        .then(response => {
            if (response.status === 401 || !response.ok) {
                alert('Your session has expired. Please log in again.');
                console.error('Heartbeat failed:', response.statusText);
                // 可以重定向到登录页面
                window.location.href = '/contact.html';
            }
            })
        .catch(error => {
            console.error('Error during heartbeat:', error);
        });
    }, 10 * 60 * 1000); // 每 10 分钟发送一次心跳
}

window.addEventListener('load', () => {               //检查会话是否过期
    fetch('/session-status', {
        method: 'GET',
        credentials: 'include' // 发送 cookies 以确保会话保持
    })
    .then(response => response.json())
    .then(data => {
        if (data.isLoggedIn) { 
            console.log('User is logged in as:', data.username);
            startHeartbeat(); // 如果用户已登录，启动心跳机制
        }
    })
    .catch(error => {
        console.error('Error checking session:', error);
    });
});

var form = document.forms[0];
document.getElementById('SendMessage').addEventListener('click', function(e){
    e.preventDefault();
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    const errorMessageDiv = document.getElementById('error-message');
    if (state == 3){
        fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
        })
        .then(response => {
        if (!response.ok) {  // 如果响应不是 200 OK，处理错误
            return response.json().then(errData => {
                throw new Error(errData.error);
            });
        }
        return response.json();
        })
        .then(data => {
            console.log(data);
            errorMessageDiv.style.color = 'green';
            errorMessageDiv.textContent = '登录成功';
            // 在页面加载时启动心跳机制
            startHeartbeat();
            window.addEventListener('load', startHeartbeat);                      
            const loginText = document.getElementById('login-text');
            if (loginText) {
                loginText.textContent = '';  // 清除登录文字
            }
        })
        .catch(error => {
            console.log('Error: ' + error.message)
            errorMessageDiv.textContent = "密码或账号错误";
        })
    } else {
        fetch('/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
        })
        .then(response => response.json())
        .then(data => console.log(data))
        .catch(error => console.error('Error:', error));
    }
});

