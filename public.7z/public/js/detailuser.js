fetch('/userdetail', {
    method: 'GET',
    headers: {
        'Content-Type': 'application/json'
    }
})
.then(response => response.json())
.then(data => {
    if (data) {
        document.getElementById('Uname').textContent = data.Uname;
        document.getElementById('Umail').textContent = data.Umail;
        document.getElementById('Uside').textContent = data.Uside;
        document.getElementById('Uinfo').textContent = data.Uinfo;
    } else {
        // 如果未找到需求，显示错误信息
        document.getElementById('userTitle').textContent = "User not found";
    }
})
.catch(error => console.error('Error:', error));